<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '## modUtilities
 это компонент добавляющий разные полезные, часто используемые, и просто интересные функции, для облегчения и стандартизации програмирования на modx
 поддерживает fenom
 
   ```fenom
  //fenom
   тег    метод    аргументы...
  {util \'makeUrl\' 24}
   тег    переменная
  {util \'constant->kb\'} 
  ```

чтобы работали подсказки в IDE вы можете добавить этот фрагмент в класс \'modX\'
это точно никак не навредит вашему проекту
```
/**
 * @var utilities utilities package.
 */
public $util;
```

  
#### Константы и переменные
 ```php
$modx->util->constant->kb       //килобайт  в байтах
$modx->util->constant->mb       //мегобайт  в байтах    
$modx->util->constant->gb       //гигобайт  в байтах
$modx->util->constant->tb       //теробайт  в байтах
$modx->util->constant->min      //минут     в секундах
$modx->util->constant->hour     //час       в секундах
$modx->util->constant->day      //день      в секундах
$modx->util->constant->week     //неделя    в секундах
$modx->util->output[\'function\']   //сюда попадает побочный вывод некоторых функций 
 ```
#### Плагины
- **modUtilities** - основной плагин расширяющий объекты класса modX и FenomX
    ##### _срабатывает на события `OnMODXInit`,`pdoToolsOnFenomInit`_
- **modUtilitiesPathGen** - автоматически генерирует пути для статичных ресурсов: чанков снипетов шаблонов и плагинов
    срабатывает при включении чекбокса `Статичный` и пустом поле `Статичный файл`
    ##### _срабатывает на события `OnChunkFormPrerender`,`OnDocFormPrerender`,`OnPluginFormPrerender`,`OnSnipFormPrerender`,`OnTempFormPrerender`_

#### Функции

- **print_n** - возвращает информацию переданную через аргументы с переносом строки
    обратите внимане функция возвращает форатированную строку но не выводит ее, не забудте добавиь `echo`
    ##### _что-то среднее между echo и var_dump_
    ```php
    $arr = [
        \'фрукт\'=>\'апельсин\',
        \'ягода\'=>\'арбуз\',
        ];
    echo $modx->util->print_n(\'у меня есть\',$arr,8);
    //(string): у меня есть, (array): {"фрукт":"апельсин","ягода":"арбуз"}, (integer): 8
    ```

- **mb_ucfirst** - возвращает и строку с заглавной буквы для любой кодировки
    ##### _функция простая но объявлять ее в каждом снипете не хочется_
    ```php
    $modx->util->mb_ucfirst(\'у меня есть\'); //У меня есть
    ```
- **translit** - транслитерирует секст с помощью установленного у вас транслитератора alias например `yTranslit`
    если такого нет то просто транслитерирует текст как для url
    ##### _~~моя любимая функция~~_
    ```php
    //с установленным "yTranslit"
    $modx->util->translit(\'у меня есть\'); //i-have
    $modx->util->cpuTranslit(\'у меня есть\'); //u-menya-est
    $modx->util->basicTranslit(\'у меня есть\'); //u menya est
    ```

- **console** - возвращает переданную во втором параметр инфомацию в вид js         скрипта     console.{действи}
    обратите внимане функция возвращает форатированную строку но не выводит ее, не забудте добавиь `echo`
    ##### _полезно при работе на рабочем сайте для вывда debug информации_
    
    ```php
    $arr = [
        \'фрукт\'=>\'апельсин\',
        \'ягода\'=>\'арбуз\',
        ];
    echo $modx->util->console(\'log\',\'у меня есть\'); 
    //<script>console.log(\'(string): у меня есть\');</script>
    echo $modx->util->console(\'debug\',$arr); 
    //<script>console.debug({"фрукт":"апельсин","ягода":"арбуз"});</script>
    echo $modx->util->console(\'table\',$arr); 
    //<script>console.table({"фрукт":"апельсин","ягода":"арбуз"});</script>
    ```

- **dateFormat** - меняет формат даты
    ##### _полезно если приходится проделывать это много раз_
    ```php
    $modx->util->dateFormat(\'d.m.Y\',\'29.01.2020\',\'Y-m-d\');//2020-01-29
    ```

- **rawText** - оставляет в строке только буквы и цифры
    ##### _полезно когда нужно сравнить две строки с не большими отличиями_
    ```php
    $modx->util->rawText(\'Abs_#)/\\(_De\');//absde
    ```
- **likeString** - сравнивает две строки либо массив строк со строкой
    и выводит самую похожую строку и процент похожести
    ```php
    $arr = [
        \'Пивет\',
        \'Прлвeт\',
        \'Приет\',
        \'тивирТ\',
        \'привт\',
        \'досвидания\',
    ];
    var_dump($modx->util->likeString($arr,\'Привет\'));
    // array (size=3)
    //   \'one\' => string \'Приет\' (length=10)
    //   \'two\' => string \'Привет\' (length=12)
    //   \'score\' => float 90,909090909091
    
    $modx->util->data[\'likeString\']; //здесь будет массив с остальными словами и их процентом схожести
    ```

- **makeUrl** - делает тоже что и обычный makeUrl только умнее: ссылка всегда начинается с \'/\', если страница равна ссылке подставляется параметр alt по умолчанию \'#top\' 
    ```php
    //php
    $modx->util->makeUrl(1,\'#top\');
    ```
    ```fenom
    //fenom
    {util \'makeUrl\' 24}
    ```

- **or** - выдает первый не пустой аргумент
    ##### _я использовал это вместе с fenom что бы не писать кучу условий_
    
    ```php
    //php
    $modx->util->or(0,false, null,\'\',\' \', \'привет\',\'кит\'); //привет
    ```
    ```fenom
    //fenom
    {util \'or\' 0 false null \'\' \' \'  \'привет\' \'кит\'}//привет
    ```


- **member** - функция для получения информации о группе пользователя

    *первый аргумент* - id пользователя если пустой то текущий авторезированный пользоваеть если авторизован

    *второй аргумент* - имя группы если установленно то, функция выдаст массив с ролью пользователя в этой группе или `false` если его в ней нет
    если yt установленно то, функция выдаст массив групп в которых состоит пользователь и его роль в них или `false`

    *третий аргумент* - можно заполнятьтолько вместе со вторым,
    функция выдаст `true` или `false`
 
    ```php
    //php
   $answer = $modx->util->member(1); 
   $answer = [
                {"groupId":"1","groupName":"Administrator","roleId":"2",    "roleName":"Super User"}
              ]
   $answer = $modx->util->member(1,\'Administrator\'); 
   $answer = {"roleId":"2","roleName":"Super User"}
   $answer = $modx->util->member(1,1,\'Super User\'); 
   $answer = true
    ```

- **plural** - функция для локализации перечисяемых объектов

',
    'readme' => '@@ -1,21 +0,0 @@
MIT License

Copyright (c) 2020 Kirill

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f2f8cdadb1192c20b44815656f045abf',
      'native_key' => 'modutilities',
      'filename' => 'modNamespace/34efe9be93f56bff583b32e5d7751183.vehicle',
      'namespace' => 'modutilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'd227e7427d90cd849343961839b4d37e',
      'native_key' => 15,
      'filename' => 'modPlugin/a0b96d36f638c53f4487ed95288d108d.vehicle',
      'namespace' => 'modutilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '119a5c8f5859eabe32b2227d83e0a754',
      'native_key' => 16,
      'filename' => 'modPlugin/2289669682544cd776ee8a8744fe655e.vehicle',
      'namespace' => 'modutilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bdb24acb7c92ed769ba646866f140340',
      'native_key' => 1,
      'filename' => 'modCategory/68fa2a04fe8bdd33a534bff27986c3b2.vehicle',
      'namespace' => 'modutilities',
    ),
  ),
);