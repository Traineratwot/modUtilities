<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020 Kirill

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '## modUtilities
 это компонент добавляющий разные полезные, часто используемые, и просто интересные функции, для облегчения и стандартизации програмирования на modx
 поддерживает fenom
  
   ```fenom
  //fenom
   тег    метод    аргументы...
  {util \'makeUrl\' 24}
   тег    переменная
  {util \'constant->kb\'} 
  ```

чтобы работали подсказки в IDE вы можете добавить этот фрагмент в класс \'modX\'
это точно никак не навредит вашему проекту
```php
/**
 * @var utilities utilities package.
 */
public $util;
```

  
#### Константы и переменные
 ```
$modx->util->constant->kb       //килобайт  в байтах
$modx->util->constant->mb       //мегобайт  в байтах    
$modx->util->constant->gb       //гигобайт  в байтах
$modx->util->constant->tb       //теробайт  в байтах
$modx->util->constant->min      //минут     в секундах
$modx->util->constant->hour     //час       в секундах
$modx->util->constant->day      //день      в секундах
$modx->util->constant->week     //неделя    в секундах
$modx->util->output[\'function\']   //сюда попадает побочный вывод некоторых функций 
 ```
#### Плагины
- **modUtilities** - основной плагин расширяющий объекты класса modX и FenomX
    ##### _срабатывает на события `OnMODXInit`,`pdoToolsOnFenomInit`_
- **modUtilitiesPathGen** - автоматически генерирует пути для статичных ресурсов: чанков снипетов шаблонов и плагинов
    срабатывает при включении чекбокса `Статичный` и пустом поле `Статичный файл`
    ##### _срабатывает на события `OnChunkFormPrerender`,`OnDocFormPrerender`,`OnPluginFormPrerender`,`OnSnipFormPrerender`,`OnTempFormPrerender`_

#### Функции

- **print_n** - возвращает информацию переданную через аргументы с переносом строки
    ##### _что-то среднее между echo и var_dump_
    ```php
    $arr = [
        \'фрукт\'=>\'апельсин\',
        \'ягода\'=>\'арбуз\',
        ];
    echo $modx->util->print_n(\'у меня есть\',$arr,8);
    //(string): у меня есть, (array): {"фрукт":"апельсин","ягода":"арбуз"}, (integer): 8
    ```

- **mb_ucfirst** - возвращает и строку с заглавной буквы для любой кодировки
    ##### _функция простая но объявлять ее в каждом снипете не хочется_
    ```php
    $modx->util->mb_ucfirst(\'у меня есть\'); //У меня есть
    ```
- **translit** - транслитерирует секст с помощью установленного у вас транслитератора alias например `yTranslit`
    если такого нет то просто транслитерирует текст как для url
    ##### _~~моя любимая функция~~_
    ```php
    //с установленным "yTranslit"
    $modx->util->translit(\'у меня есть\'); //i-have
    $modx->util->cpuTranslit(\'у меня есть\'); //u-menya-est
    $modx->util->basicTranslit(\'у меня есть\'); //u menya est
    ```

- **console** - возвращает переданную во втором параметр инфомацию в вид js скрипта console.{действи}
    ##### _полезно при работе на рабочем сайте для вывда debug информации_
    
    ```php
    $arr = [
        \'фрукт\'=>\'апельсин\',
        \'ягода\'=>\'арбуз\',
        ];
    echo $modx->util->console(\'log\',\'у меня есть\'); 
    //<script>console.log(\'(string): у меня есть\');</script>
    echo $modx->util->console(\'debug\',$arr); 
    //<script>console.debug({"фрукт":"апельсин","ягода":"арбуз"});</script>
    echo $modx->util->console(\'table\',$arr); 
    //<script>console.table({"фрукт":"апельсин","ягода":"арбуз"});</script>
    ```

- **dateFormat** - меняет формат даты
    ##### _полезно если приходится проделывать это много раз_
    ```php
    $modx->util->dateFormat(\'d.m.Y\',\'29.01.2020\',\'Y-m-d\');//2020-01-29
    ```

- **rawText** - оставляет в строке только буквы и цифры
    ##### _полезно когда нужно сравнить две строки с не большими отличиями_
    ```php
    $modx->util->rawText(\'Abs_#)/\\(_De\');//absde
    ```
- **likeString** - сравнивает две строки либо массив строк со строкой
    и выводит самую похожую строку и процент похожести
    ```php
    $arr = [
        \'Пивет\',
        \'Прлвeт\',
        \'Приет\',
        \'тивирТ\',
        \'привт\',
        \'досвидания\',
    ];
    var_dump($modx->util->likeString($arr,\'Привет\'));
    // array (size=3)
    //   \'one\' => string \'Приет\' (length=10)
    //   \'two\' => string \'Привет\' (length=12)
    //   \'score\' => float 90,909090909091
    
    $modx->util->data[\'likeString\']; //здесь будет массив с остальными словами и их процентом схожести
    ```

- **makeUrl** - делает тоже что и обычный makeUrl только умнее: ссылка всегда начинается с \'/\', если страница равна ссылке подставляется параметр alt по умолчанию \'#top\' 
    ```php
    //php
    $modx->util->makeUrl(1,\'#top\');
    ```
    ```fenom
    //fenom
    {util \'makeUrl\' 24}
    ```

- **makeUrl** - выдает первый не пустой аргумент
    ##### _я использовал это вместе с fenom что бы не писать кучу условий_
    
    ```php
    $modx->util->or(0,false, null,\'\',\' \', \'привет\',\'кит\'); //привет
    ```
    ```fenom
    {util \'or\' 0 false null \'\' \' \'  \'привет\' \'кит\'}//привет
    ```




',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f4659b787ffa7cdf1520310fbf7d5854',
      'native_key' => 'modutilities',
      'filename' => 'modNamespace/fd5f180533d8c81f3fe4c351b5d747e9.vehicle',
      'namespace' => 'modutilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'cb973d3d0dd7451e28c95e9c87ca9578',
      'native_key' => 15,
      'filename' => 'modPlugin/b7f91d16cb512d32b7b7cb0bcb2da452.vehicle',
      'namespace' => 'modutilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '595995bbebbe4f25f7c14aa88fd6a2bc',
      'native_key' => 16,
      'filename' => 'modPlugin/5a4302a8e34fa291102cbcea93b59568.vehicle',
      'namespace' => 'modutilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1e7bc3c3ed23d49ad8a996b4226f7a40',
      'native_key' => 1,
      'filename' => 'modCategory/7b3041dc4a5d1d41d0d478a6afb62013.vehicle',
      'namespace' => 'modutilities',
    ),
  ),
);