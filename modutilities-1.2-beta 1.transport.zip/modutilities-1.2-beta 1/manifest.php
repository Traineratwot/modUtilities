<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '## modUtilities
 это компонент добавляющий разные полезные, часто используемые, и просто интересные функции, для облегчения и стандартизации програмирования на modx
 поддерживает fenom
 
 ```fenom
 тег    метод    аргументы...
{util \'makeUrl\' 24} 
```
 
##### константы и переменные
 ```
$modx->util->constant::kb       //килобайт  в байтах
$modx->util->constant::mb       //мегобайт  в байтах    
$modx->util->constant::gb       //гигобайт  в байтах
$modx->util->constant::tb       //теробайт  в байтах
$modx->util->constant::min      //минут     в секундах
$modx->util->constant::hour     //час       в секундах
$modx->util->constant::day      //день      в секундах
$modx->util->constant::week     //неделя    в секундах
$modx->util->data[\'function\']   //сюда попадает побочный вывод некоторых функций 
 ```
##### функции

**print_n** - возвращает и выводит инфрмацию переданную черз аргумент с переносом строки
######_чтото среднее между echo и var_dump_
```php
$arr = [
    \'фрукт\'=>\'апельсин\',
    \'ягода\'=>\'арбуз\',
    ];
$modx->util->print_n(\'у меня есть\',$arr,8);
//(string): у меня есть, (array): {"фрукт":"апельсин","ягода":"арбуз"}, (integer): 8
```

**mb_ucfirst** - возвращает и строку с заглавной буквы для любой кодировки
######_функция простая но объявлять ее в каждом снипете не хочется_
```php
$modx->util->mb_ucfirst(\'у меня есть\'); //У меня есть
```
**translit** - транслитирует секст с помощью установленного у вас транслитератора alias например yTranslit
если такого нет то просто траслитирует текст как для url
######_~~моя любимая функция~~_
```php
//с установленным "yTranslit"
$modx->util->translit(\'у меня есть\'); //i-have
$modx->util->cpuTranslit(\'у меня есть\'); //u-menya-est
$modx->util->basicTranslit(\'у меня есть\'); //u menya est
```

**console** - выводит переданную во втором параметр инфомацию в вид js скрипта console.{действи}
######_полезно при работе на рабочем сайте для вывда debug информации_

```php
$arr = [
    \'фрукт\'=>\'апельсин\',
    \'ягода\'=>\'арбуз\',
    ];
$modx->util->console(\'log\',\'у меня есть\'); 
//<script>console.log(\'php_string: test\');</script>
$modx->util->console(\'debug\',$arr); 
//<script>console.debug(\'php_array: {"фрукт":"апельсин","ягода":"арбуз"}\');</script>
$modx->util->console(\'table\',$arr); 
//<script>console.table({"фрукт":"апельсин","ягода":"арбуз"});</script>
```

**dateFormat** - меняет формат даты
######_полезно если приходится проделывать это много раз_
```php
$modx->util->dateFormat(\'d.m.Y\',\'29.01.2020\',\'Y-m-d\');//2020-01-29
```

**rawText** - оставляет в строке только буквы и цифры
######_полезно когда нужно сравнить две строки с не большими отличиями_
```php
$modx->util->rawText(\'Abs_#)/\\(_De\');//absde
```
**likeString** - сравнивает две строки либо массив строк со строкой
и выводит самую похожую строку и процент похожести
```php
$arr = [
    \'Пивет\',
    \'Прлвeт\',
    \'Приет\',
    \'тивирТ\',
    \'привт\',
    \'досвидания\',
];
var_dump($modx->util->likeString($arr,\'Привет\'));
// array (size=3)
//   \'one\' => string \'Приет\' (length=10)
//   \'two\' => string \'Привет\' (length=12)
//   \'score\' => float 90,909090909091

$modx->util->data[\'likeString\']; //здесь будет массив с остальными словами и их процентом схожести
```

**makeUrl** - делает тоже что и обычный makeUrl только умнее: ссылка всегда начинается с \'/\', если страница равна ссылке подставляется параметр alt по умолчанию \'#top\' 
```php
//php
$modx->util->makeUrl(1,\'#top\');
```
```fenom
//fenom
{util \'makeUrl\' 24}
```

**makeUrl** - выдает первый не пустой аргумент
```php
$modx->util->or(0,false, null,\'\',\' \', \'привет\',\'кит\'); //привет
```




',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7c8ce002ff67efde2a0f5f1b44c1e51f',
      'native_key' => 'modutilities',
      'filename' => 'modNamespace/6b4243b5760d30163f5a5d206fc10d76.vehicle',
      'namespace' => 'modutilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '5065c3b9c34f4570645ca239cf57a65a',
      'native_key' => 15,
      'filename' => 'modPlugin/abde3d85527d3df1d612bc39cbf8f56a.vehicle',
      'namespace' => 'modutilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '9641d39e70a90b9a0bd2add2e54ecd6a',
      'native_key' => 16,
      'filename' => 'modPlugin/a75c671f7174353a661be85ade8e9266.vehicle',
      'namespace' => 'modutilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5102e0ca206be377c12ba16c51e9179f',
      'native_key' => 1,
      'filename' => 'modCategory/3849162822c8f297df34d851e0be209f.vehicle',
      'namespace' => 'modutilities',
    ),
  ),
);