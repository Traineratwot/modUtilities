<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9e9264a49a1ef588a4e11d64550a8c2f',
      'native_key' => 'modutilities',
      'filename' => 'modNamespace/971293a94ed44338aa4367a1e5d48a18.vehicle',
      'namespace' => 'modutilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '56fba90340f0c582b44fbb6056931cd4',
      'native_key' => 15,
      'filename' => 'modPlugin/7f53df477062819a9bf3400281e48438.vehicle',
      'namespace' => 'modutilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'c46969f4660b674b2931d99cc32640a2',
      'native_key' => 16,
      'filename' => 'modPlugin/d3f0760acf0793ca2adbdfcfff9a9ba0.vehicle',
      'namespace' => 'modutilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '255f8a623dfeff80e86445c3b2cd4125',
      'native_key' => 1,
      'filename' => 'modCategory/761615bf1522637251ceb57414b1500c.vehicle',
      'namespace' => 'modutilities',
    ),
  ),
);