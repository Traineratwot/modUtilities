<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd96d5388a7ef840f82fbb63ccc74f319',
      'native_key' => 'modutilities',
      'filename' => 'modNamespace/18444180b58551dac6f22f70c3c70731.vehicle',
      'namespace' => 'modutilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'd06a993ca3dd29e1dcaa63d9ab6d491c',
      'native_key' => 15,
      'filename' => 'modPlugin/f034e8c7da3689425c08917bc6abd41f.vehicle',
      'namespace' => 'modutilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'fc996657b3d4af50276d08859c71ad94',
      'native_key' => 16,
      'filename' => 'modPlugin/765ac7652af7ab461e325588f382a091.vehicle',
      'namespace' => 'modutilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '956fde6ecccb4b0fae0ab2d7cd515a26',
      'native_key' => 1,
      'filename' => 'modCategory/3b72935a8d98a2b0d1f1d716944427f3.vehicle',
      'namespace' => 'modutilities',
    ),
  ),
);