<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '## modUtilities
 это компонент добавляющий разные полезные, часто используемые, и просто интересные функции, для облегчения и стандартизации програмирования на modx
 поддерживает fenom
  
   ```fenom
  //fenom
   тег    метод    аргументы...
  {util \'makeUrl\' 24}
   тег    переменная
  {util \'constant->kb\'} 
  ```

чтобы работали подсказки в IDE вы можете добавить этот фрагмент в класс \'modX\'
это точно никак не навредит вашему проекту
```php
/**
 * @var utilities utilities package.
 */
public $util;
```

  
##### константы и переменные
 ```
$modx->util->constant::kb       //килобайт  в байтах
$modx->util->constant::mb       //мегобайт  в байтах    
$modx->util->constant::gb       //гигобайт  в байтах
$modx->util->constant::tb       //теробайт  в байтах
$modx->util->constant::min      //минут     в секундах
$modx->util->constant::hour     //час       в секундах
$modx->util->constant::day      //день      в секундах
$modx->util->constant::week     //неделя    в секундах
$modx->util->data[\'function\']   //сюда попадает побочный вывод некоторых функций 
 ```
##### функции

**print_n** - возвращает информацию переданную через аргументы с переносом строки
######_что-то среднее между echo и var_dump_
```php
$arr = [
    \'фрукт\'=>\'апельсин\',
    \'ягода\'=>\'арбуз\',
    ];
echo $modx->util->print_n(\'у меня есть\',$arr,8);
//(string): у меня есть, (array): {"фрукт":"апельсин","ягода":"арбуз"}, (integer): 8
```

**mb_ucfirst** - возвращает и строку с заглавной буквы для любой кодировки
######_функция простая но объявлять ее в каждом снипете не хочется_
```php
$modx->util->mb_ucfirst(\'у меня есть\'); //У меня есть
```
**translit** - транслитерирует секст с помощью установленного у вас транслитератора alias например `yTranslit`
если такого нет то просто транслитерирует текст как для url
######_~~моя любимая функция~~_
```php
//с установленным "yTranslit"
$modx->util->translit(\'у меня есть\'); //i-have
$modx->util->cpuTranslit(\'у меня есть\'); //u-menya-est
$modx->util->basicTranslit(\'у меня есть\'); //u menya est
```

**console** - возвращает переданную во втором параметр инфомацию в вид js скрипта console.{действи}
######_полезно при работе на рабочем сайте для вывда debug информации_

```php
$arr = [
    \'фрукт\'=>\'апельсин\',
    \'ягода\'=>\'арбуз\',
    ];
echo $modx->util->console(\'log\',\'у меня есть\'); 
//<script>console.log(\'(string): у меня есть\');</script>
echo $modx->util->console(\'debug\',$arr); 
//<script>console.debug({"фрукт":"апельсин","ягода":"арбуз"});</script>
echo $modx->util->console(\'table\',$arr); 
//<script>console.table({"фрукт":"апельсин","ягода":"арбуз"});</script>
```

**dateFormat** - меняет формат даты
######_полезно если приходится проделывать это много раз_
```php
$modx->util->dateFormat(\'d.m.Y\',\'29.01.2020\',\'Y-m-d\');//2020-01-29
```

**rawText** - оставляет в строке только буквы и цифры
######_полезно когда нужно сравнить две строки с не большими отличиями_
```php
$modx->util->rawText(\'Abs_#)/\\(_De\');//absde
```
**likeString** - сравнивает две строки либо массив строк со строкой
и выводит самую похожую строку и процент похожести
```php
$arr = [
    \'Пивет\',
    \'Прлвeт\',
    \'Приет\',
    \'тивирТ\',
    \'привт\',
    \'досвидания\',
];
var_dump($modx->util->likeString($arr,\'Привет\'));
// array (size=3)
//   \'one\' => string \'Приет\' (length=10)
//   \'two\' => string \'Привет\' (length=12)
//   \'score\' => float 90,909090909091

$modx->util->data[\'likeString\']; //здесь будет массив с остальными словами и их процентом схожести
```

**makeUrl** - делает тоже что и обычный makeUrl только умнее: ссылка всегда начинается с \'/\', если страница равна ссылке подставляется параметр alt по умолчанию \'#top\' 
```php
//php
$modx->util->makeUrl(1,\'#top\');
```
```fenom
//fenom
{util \'makeUrl\' 24}
```

**makeUrl** - выдает первый не пустой аргумент
######_я использовал это вместе с fenom что бы не писать кучу условий_

```php
$modx->util->or(0,false, null,\'\',\' \', \'привет\',\'кит\'); //привет
```
```fenom
{util \'or\' 0 false null \'\' \' \'  \'привет\' \'кит\'}//привет
```




',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '925d2ae0b22396fc0b13e7c8be226d75',
      'native_key' => 'modutilities',
      'filename' => 'modNamespace/88ea334961846c0ffdc8c4b8494e1d59.vehicle',
      'namespace' => 'modutilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'fe9077bbf571e3fa7f6a2fda65e89fdd',
      'native_key' => 15,
      'filename' => 'modPlugin/7a95ce1ae78be2a976dfd182346acb33.vehicle',
      'namespace' => 'modutilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '45625406f707158221cd38fb6c136369',
      'native_key' => 16,
      'filename' => 'modPlugin/4d9168442b5d81bfa2d8661b9fe6a85b.vehicle',
      'namespace' => 'modutilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '41ac1724f747db901316267f62a77028',
      'native_key' => 1,
      'filename' => 'modCategory/a900e350708dfdba28dbcfe379e2f313.vehicle',
      'namespace' => 'modutilities',
    ),
  ),
);