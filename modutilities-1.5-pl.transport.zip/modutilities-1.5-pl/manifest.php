<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3407b5668228277f65bdebf5bed6cdd0',
      'native_key' => 'modutilities',
      'filename' => 'modNamespace/50479cb86e1c32d288d733599a14648a.vehicle',
      'namespace' => 'modutilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '5bff5491c6d2b21153b893e04951a564',
      'native_key' => 15,
      'filename' => 'modPlugin/801975d17e60d9e10f5895b66f4ca3c5.vehicle',
      'namespace' => 'modutilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'b12033361ff5ea13dea1d8bade5cb9d6',
      'native_key' => 16,
      'filename' => 'modPlugin/df89c1db9794c85228c196355cb96ec5.vehicle',
      'namespace' => 'modutilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8ddc6d1f17ac57936ab8acbc106af261',
      'native_key' => 1,
      'filename' => 'modCategory/98e03dd6aeac65c3b912f503a0b070f4.vehicle',
      'namespace' => 'modutilities',
    ),
  ),
);