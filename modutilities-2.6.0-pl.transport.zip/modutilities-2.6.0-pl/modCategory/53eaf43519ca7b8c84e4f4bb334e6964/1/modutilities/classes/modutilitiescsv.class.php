<?php
	/**
	 * Created by Kirill Nefediev..
	 * Date: 04.06.2020
	 * Time: 18:04
	 */

	class modutilitiesCsv
	{
		/* @var modX $modX */
		public $modx;
		/* @var modutilities $util */
		public $util;
		/* @var string chr(239) . chr(187) . chr(191) */
		public $utf8bom;
		/* @var string Charset */
		public $inputCharset;
		/* @var string output csv string */
		protected $csv;
		/* @var string output html string */
		protected $html;
		/* @var array */
		protected $matrix;
		/* @var array */
		protected $head = [];
		protected $appendType = FALSE;
		protected $str_delimiter;
		protected $line_delimiter;
		protected $escape;
		public $currentRow = -1;
		public $currentCol = -1;

		/**
		 * UtilitiesCsv constructor
		 * param [
		 *  inputCharset | 'utf8'
		 *    woBom - without BOM | false
		 *    delimiter |';'
		 *    line_delimiter | PHP_EOL
		 * ]
		 * @param modX      $modx
		 * @param utilities $util
		 * @param array     $param
		 */
		public function __construct(modX &$modx, modutilities &$util, $param = [])
		{
			$this->inputCharset = isset($param['inputCharset']) ? $param['inputCharset'] : 'utf8';
			$this->modx = $modx;
			$this->util = $util;

			$this->utf8bom = (isset($param['woBom']) and $param['woBom'] = TRUE) ? NULL : chr(239) . chr(187) . chr(191);
			$this->str_delimiter = isset($param['delimiter']) ? $param['delimiter'] : ';';
			$this->line_delimiter = isset($param['line_delimiter']) ? $param['line_delimiter'] : "\n";
			$this->escape = isset($param['escape']) ? $param['escape'] : '"';
		}

		/**
		 * @param array $param
		 * @return $this
		 */
		public function reset($param = [])
		{
			$this->inputCharset = isset($param['inputCharset']) ? $param['inputCharset'] : $this->inputCharset;
			$this->utf8bom = (isset($param['woBom']) and $param['woBom'] = TRUE) ? NULL : $this->utf8bom;
			$this->str_delimiter = isset($param['delimiter']) ? $param['delimiter'] : $this->str_delimiter;
			$this->line_delimiter = isset($param['line_delimiter']) ? $param['line_delimiter'] : $this->line_delimiter;
			$this->csv = NULL;
			$this->html = NULL;
			$this->matrix = NULL;
			$this->head = [];
			$this->appendType = FALSE;
			return $this;
		}

		/**
		 * add row to csv
		 * @return $this|bool
		 */
		public function addRow()
		{
			if (!$this->appendType or !$this->util->empty(($this->matrix))) {
				$this->appendType = 'row';
			}
			if ($this->appendType != 'row') {
				return FALSE;
			}
			$args = func_get_args();
			if (count($args) == 1 and is_array($args[0])) {
				$args = $args[0];
			}
			$head = array_flip($this->head);
			$isAssoc = $this->util->isAssoc($args);
			$args_ = [];
			foreach ($args as $k => $art) {
				$art = $this->escape.$art.$this->escape;
				if ($isAssoc) {
					if (!is_string($art) and !is_numeric($art)) {
						$args_[$head[$k]] = NULL;
					} else {
						$args_[$head[$k]] = (string)$art;
					}
				} else {
					if (!is_string($art) and !is_numeric($art)) {
						$args_[$k] = NULL;
					} else {
						$args_[$k] = (string)$art;
					}
				}
			}
			$this->matrix[] = $args_;
			$this->matrixFix();

			return $this;
		}

		/**
		 * add column to csv
		 * @return $this|bool
		 */
		public function addCol()
		{
			if (!$this->appendType or !$this->util->empty(($this->matrix))) {
				$this->appendType = 'column';
			}
			if ($this->appendType != 'column') {
				return FALSE;
			}
			$args = func_get_args();
			if (count($args) == 1 and is_array($args[0])) {
				$args = $args[0];
			}
			$head = array_flip($this->head);
			$isAssoc = $this->util->isAssoc($args);
			foreach ($args as $k => $art) {
				$art = $this->escape.$art.$this->escape;
				if (!is_string($art) and !is_numeric($art)) {
					$art = NULL;
				} else {
					$art = (string)$art;
				}
				if ($isAssoc) {
					$this->matrix[$head[$k]][] = $art;
				} else {
					$this->matrix[$k][] = $art;
				}
			}
			$this->matrixFix();

			return $this;
		}

		/**
		 * add header for csv
		 * @return $this
		 */
		public function setHead()
		{
			$args = func_get_args();
			if (count($args) == 1 and is_array($args[0])) {
				$args = $args[0];
			}
			foreach ($args as $k => $art) {
				$art = $this->escape.$art.$this->escape;
				if (!is_string($art) and !is_numeric($art)) {
					$args[$k] = NULL;
				} else {
					$args[$k] = (string)$art;
				}
			}
			$this->head = $args;
			$this->matrixFix();

			return $this;
		}

		/**
		 * @param string|int $x column
		 * @param string|int $y row
		 * @param string|int $value
		 */
		public function setCell($x = 0, $y = 0, $value = '')
		{
			if (!empty($this->head)) {
				switch ($this->appendType) {
					case 'row':
						if (in_array($x, $this->head)) {
							$head = array_flip($this->head);
							$x = $head[$x];
						}
						break;
					case 'column':
						if (in_array($y, $this->head)) {
							$head = array_flip($this->head);
							$y = $head[$y];
						}
						break;
					default:
						return FALSE;
				}
			}
			$x = (int)$x;
			$y = (int)$y;
			for ($i = 0; $i <= $y; $i++) {
				if (!array_key_exists($i, $this->matrix)) {
					$this->matrix[$i] = [];
				}
			}
			for ($i = 0; $i <= $x; $i++) {
				if ($i == $x) {
					$this->matrix[$y][$i] = $value;
				}
				if (!array_key_exists($i, $this->matrix[$y])) {
					$this->matrix[$y][$i] = '';
				}
			}
			return $this;
		}

		/**
		 * @param string|int $x
		 * @param string|int $y
		 * @return bool|mixed
		 */
		public function getCell($x = 0, $y = 0)
		{
			if (!empty($this->head)) {
				switch ($this->appendType) {
					case 'row':
						if (in_array($x, $this->head)) {
							$head = array_flip($this->head);
							$x = $head[$x];
						}
						break;
					case 'column':
						if (in_array($y, $this->head)) {
							$head = array_flip($this->head);
							$y = $head[$y];
						}
						break;
					default:
						return FALSE;
				}
			}
			$x = (int)$x;
			$y = (int)$y;
			if (isset($this->matrix[$y]) and isset($this->matrix[$y][$x])) {
				return $this->matrix[$y][$x];
			}
			return FALSE;
		}

		private function matrixFix()
		{
			$lenCol[] = count($this->head);
			if (is_array($this->matrix)) {
				foreach ($this->matrix as $row) {
					$lenCol[] = count($row);
				}
				$lenCol = max($lenCol);
				foreach ($this->matrix as $k => $row) {
					for ($i = 0; $lenCol > $i; $i++) {
						if (!isset($row[$i])) {
							$this->matrix[$k][$i] = NULL;
						}
					}
				}
			}
		}

		/**
		 *generate csv string
		 */
		public function _buildCsv()
		{
			$this->sort();
			$this->csv = $this->utf8bom;
			$len = [];
			$head = $this->head;
			$len[] = count($head);
			foreach ($this->matrix as $row) {
				$len[] = count($row);
			}
			$len = max($len);
			if (!empty($head)) {
				if ($this->appendType == 'row') {
					$this->csv .= implode($this->str_delimiter, $head);
				} else {
					foreach ($this->head as $k => $h) {
						array_unshift($this->matrix[$k], $h);
					}
				}
			}
			foreach ($this->matrix as $key => $row) {
				$_row = [];
				for ($i = 0; $i < $len; $i++) {
					$_row[$i] = (isset($row[$i])) ? $row[$i] : '';
				}
				if (!$this->util->empty($_row)) {
					$this->csv .= $this->line_delimiter;
					$this->csv .= implode($this->str_delimiter, $_row);
				}
			}
		}

		/**
		 *generate html table string
		 */
		public function _buildHtmlTable($cls = '')
		{
			$this->sort();
			$this->html = "<table class=\"$cls\">";
			$len = [];
			$head = $this->head;
			$len[] = count($head);
			foreach ($this->matrix as $row) {
				$len[] = count($row);
			}
			$len = max($len);
			if (!empty($head)) {
				if ($this->appendType == 'row') {
					$this->html .= "<tr>";
					foreach ($head as $h) {
						$this->html .= "<th>$h</th>";
					}
					$this->html .= "</tr>";
				} else {
					foreach ($this->head as $k => $h) {
						array_unshift($this->matrix[$k], $h);
					}
				}
			}
			foreach ($this->matrix as $key => $row) {
				$_row = [];
				for ($i = 0; $i < $len; $i++) {
					$_row[$i] = (isset($row[$i])) ? $row[$i] : '';
				}
				if (!$this->util->empty($_row)) {
					$this->html .= "<tr>";
					$i = 0;
					foreach ($row as $r) {
						$i++;
						if ($this->head and $this->appendType == 'column' and $i == 1) {
							$this->html .= "<th>$r</th>";
						} else {
							$this->html .= "<td>$r</td>";
						}
					}
					$this->html .= "</tr>";
				}
			}
			$this->html .= '</table>';
		}

		/**
		 * @param string $cls
		 * @param string $delimiter
		 * @param string $item li|ol
		 */
		public function _buildHtmlList($cls = '', $delimiter = ' ', $item = 'li')
		{
			$this->sort();
			$this->html = "<ul class=\"$cls\">";
			$len = [];
			$head = $this->head;
			$len[] = count($head);
			foreach ($this->matrix as $row) {
				$len[] = count($row);
			}
			$len = max($len);
			if (!empty($head)) {
				if ($this->appendType == 'row') {
					$this->html .= "<$item>";
					foreach ($head as $h) {
						$this->html .= "<strong>$h</strong>" . $delimiter;
					}
					$this->html .= "</$item>";
				} else {
					foreach ($this->head as $k => $h) {
						array_unshift($this->matrix[$k], $h);
					}
				}
			}
			foreach ($this->matrix as $key => $row) {
				$_row = [];
				for ($i = 0; $i < $len; $i++) {
					$_row[$i] = (isset($row[$i])) ? $row[$i] : '';
				}
				if (!$this->util->empty($_row)) {
					$this->html .= "<$item>";
					$i = 0;
					foreach ($row as $r) {
						$i++;
						if ($this->head and $this->appendType == 'column' and $i == 1) {
							$this->html .= "<strong>$r</strong>" . $delimiter;
						} else {
							$this->html .= "<span>$r</span>" . $delimiter;
						}
					}
					$this->html .= "</$item>";
				}
			}
			$this->html .= '</ul>';
		}

		/**
		 * @return String
		 */
		public function toCsv()
		{
			$this->_buildCsv();
			return (string)$this->csv;
		}

		/**
		 * @param string $cls
		 * @return String
		 */
		public function toHtml($cls = '')
		{
			$this->_buildHtmlTable($cls);
			return (string)$this->html;
		}

		/**
		 * @param string $cls
		 * @return String
		 */
		public function toHtmlTable($cls = '')
		{
			$this->_buildHtmlTable($cls);
			return (string)$this->html;
		}

		/**
		 * @param string $cls
		 * @param string $delimiter
		 * @param string $item UL, OL, LI и DL
		 * @return String
		 */
		public function toHtmlList($cls = '', $delimiter = '', $item = 'li')
		{
			$this->_buildHtmlList($cls, $delimiter, $item);
			return $this->html;
		}

		/**
		 * @param resource|string $source
		 * @return $this|false
		 * @filesource
		 */
		public function readCsv($source)
		{
			switch (gettype($source)) {
				case 'string':
					if (!$this->util->strTest($source, "\n", [$this->line_delimiter, $this->str_delimiter]) and file_exists($source)) {
						$source = @fopen($source, 'r');
						return $this->_readCsvResource($source);
					} else {
						return $this->_readCsvString($source);
					}
				case'resource':
					return $this->_readCsvResource($source);
				default:
					return FALSE;
			}
		}

		/**
		 * @param resource $source
		 * @return $this
		 */
		final private function _readCsvResource($source)
		{
			if(is_resource($source)) {
				$i = 0;
				while (($row = fgetcsv($source, 10240, $this->str_delimiter))) {
					$i++;
					if ($i === 1) {
						$this->setHead($row);
						continue;
					}
					$this->addRow($row);
				}
				fclose($source);
			}
			return $this;
		}

		/**
		 * @param string $source
		 * @return $this
		 */
		final private function _readCsvString($source)
		{
			$i = 0;
			//$rows = str_getcsv($source,$this->str_delimiter);
			$rows = explode($this->line_delimiter, $source);
			foreach ($rows as $row) {
				$i++;
				$row = explode($this->str_delimiter, $row);
				if ($i === 1) {
					$this->setHead($row);
					continue;
				}
				$this->addRow($row);
			}
			return $this;
		}

		/**
		 * @return array
		 */
		public function toArray()
		{
			return $this->matrix;
		}

		public function getRow()
		{
			if ($this->currentRow == -1) {
				$this->currentRow++;
				return $this->head;
			}
			$row = (isset($this->matrix[$this->currentRow])) ? $this->matrix[$this->currentRow] : FALSE;
			if ($row) {
				$this->currentRow++;
				return $row;
			} else {
				$this->currentRow = 0;
				return FALSE;
			}
		}

		public function getCol()
		{
			if ($this->currentCol == -1) {
				$this->currentCol++;
				return $this->head;
			}
			$col = [];
			foreach ($this->matrix as $v) {
				if (isset($v[$this->currentCol])) {
					$col[] = $v[$this->currentCol];
				}
			}
			if ($col) {
				$this->currentCol++;
				return $col;
			} else {
				$this->currentCol = 0;
				return FALSE;
			}
		}

		/**
		 * @return csvString|string
		 */
		final public function __toString()
		{
			return (string)$this->toCsv();
		}

		/**
		 * @param $name
		 * @return bool
		 */
		final public function __isset($name)
		{
			return TRUE;
		}

		/**
		 * @param $name
		 * @return bool
		 */
		final public function __get($name)
		{
			switch ($name) {
				case 'matrix':
					return $this->matrix;

				default:
					return FALSE;

			}
		}

		private function sort()
		{
			ksort($this->head);
			foreach ($this->matrix as $k => $v) {
				ksort($this->matrix[$k]);
			}
		}

		/**
		 * @param $name
		 * @param $value
		 * @return $this|false|string
		 */
		final public function __set($name, $value)
		{
			switch ($name) {
				case 'matrix':
					$this->matrix = $value;
				case 'csv':
					return $this->readCsv($value);
			}
			return FALSE;
		}
	}
