<?php
require_once (dirname(__DIR__) . '/utilrest.class.php');
class Utilrest_mysql extends Utilrest {}