<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'Utilrest',
    1 => 'Utilrestcategory',
  ),
  'xPDOObject' => 
  array (
    0 => 'Utilreststats',
  ),
);