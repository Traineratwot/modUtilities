<?php
require_once (dirname(__DIR__) . '/utilreststats.class.php');
class Utilreststats_mysql extends Utilreststats {}