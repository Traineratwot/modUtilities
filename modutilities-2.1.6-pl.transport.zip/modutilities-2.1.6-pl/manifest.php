<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'modutilities-2.1.6-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1ef9109fb9dd0ba2bcd74271656ba8dd',
      'native_key' => 'modUtilities',
      'filename' => 'modNamespace/b70eaded6c7ee1a70378709ae9738330.vehicle',
      'namespace' => 'modUtilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '13e782e14ce441369175579b9d4b893e',
      'native_key' => 15,
      'filename' => 'modPlugin/52f205b149c2a4d85076db5a8686208a.vehicle',
      'namespace' => 'modUtilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '2f513f5d4ba0b55c46269aef34614599',
      'native_key' => 16,
      'filename' => 'modPlugin/774f163ce218121117e733af631425c9.vehicle',
      'namespace' => 'modUtilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'afcfe62e46e9314705ec924752892d6b',
      'native_key' => 1,
      'filename' => 'modCategory/d857ffdeb5cea7869e9a1809e99e0f79.vehicle',
      'namespace' => 'modUtilities',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9b67a12f12f3487b9159d41b3079d22d',
      'native_key' => 'modUtilities',
      'filename' => 'modMenu/c15b1d67ca7f3ed4e78768e528ad7fb5.vehicle',
      'namespace' => 'modUtilities',
    ),
  ),
);