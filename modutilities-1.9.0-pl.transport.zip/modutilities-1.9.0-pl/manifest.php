<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3fca1d4086c3c3126aa1c6402e05b3f2',
      'native_key' => 'modutilities',
      'filename' => 'modNamespace/a167c4f40237ee5924fd6874eeadb20d.vehicle',
      'namespace' => 'modutilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '026514cb0109c89fbbbd144d374476de',
      'native_key' => 15,
      'filename' => 'modPlugin/ed801371c59efe8ad2268e85d6cbd4b1.vehicle',
      'namespace' => 'modutilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '85dfcb99ed4c54cdde64555e3f71f5b8',
      'native_key' => 16,
      'filename' => 'modPlugin/a99e599a4237aa9741478669be6c110f.vehicle',
      'namespace' => 'modutilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b7ec495a42e42eb1d339a9cbcd726217',
      'native_key' => 1,
      'filename' => 'modCategory/1a78a4a8213ba2de8ab528bd71100e35.vehicle',
      'namespace' => 'modutilities',
    ),
  ),
);