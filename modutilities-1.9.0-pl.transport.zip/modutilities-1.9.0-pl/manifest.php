<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '@@ -1,21 +0,0 @@
MIT License

Copyright (c) 2020 Kirill

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '## modUtilities
 это компонент добавляющий разные полезные, часто используемые, и просто интересные функции, для облегчения и стандартизации програмирования на modx
 поддерживает fenom
 
   ```fenom
  //fenom
   тег    метод    аргументы...
  {util \'makeUrl\' 24}
   тег    переменная
  {util \'constant->kb\'} 
  ```

чтобы работали подсказки в IDE вы можете добавить этот фрагмент в класс \'modX\'
это точно никак не навредит вашему проекту
```
/**
* @var utilities utilities package.
*/
public $util;
```

#### Константы и переменные
 ```php
$modx->util->constant->kb       //килобайт  в байтах
$modx->util->constant->mb       //мегобайт  в байтах    
$modx->util->constant->gb       //гигобайт  в байтах
$modx->util->constant->tb       //теробайт  в байтах
$modx->util->constant->min      //минут     в секундах
$modx->util->constant->hour     //час       в секундах
$modx->util->constant->day      //день      в секундах
$modx->util->constant->week     //неделя    в секундах
$modx->util->output[\'function\']   //сюда попадает побочный вывод некоторых функций 
 ```
#### Плагины
- **modUtilities** - основной плагин расширяющий объекты класса modX и FenomX
    _срабатывает на события `OnMODXInit`,`pdoToolsOnFenomInit`_
- **modUtilitiesPathGen** - автоматически генерирует пути для статичных ресурсов: чанков снипетов шаблонов и плагинов
    срабатывает при включении чекбокса `Статичный` и пустом поле `Статичный файл`
    _срабатывает на события `OnChunkFormPrerender`,`OnDocFormPrerender`,`OnPluginFormPrerender`,`OnSnipFormPrerender`,`OnTempFormPrerender`_

#### Функции

- **print_n** - возвращает информацию переданную через аргументы с переносом строки
    обратите внимане функция возвращает форатированную строку но не выводит ее, не забудте добавиь `echo`
    _что-то среднее между echo и var_dump_
    ```php
    $arr = [
        \'фрукт\'=>\'апельсин\',
        \'ягода\'=>\'арбуз\',
        ];
    echo $modx->util->print_n(\'у меня есть\',$arr,8);
    //(string): у меня есть, (array): {"фрукт":"апельсин","ягода":"арбуз"}, (integer): 8
    ```

- **mb_ucfirst** - возвращает и строку с заглавной буквы для любой кодировки
    _функция простая но объявлять ее в каждом снипете не хочется_
    ```php
    $modx->util->mb_ucfirst(\'у меня есть\'); //У меня есть
    ```
- **translit** - транслитерирует секст с помощью установленного у вас транслитератора alias например `yTranslit`
    если такого нет то просто транслитерирует текст как для url
    _~~моя любимая функция~~_
    ```php
    //с установленным "yTranslit"
    $modx->util->translit(\'у меня есть\'); //i-have
    $modx->util->cpuTranslit(\'у меня есть\'); //u-menya-est
    $modx->util->basicTranslit(\'у меня есть\'); //u menya est
    ```

- **console** - возвращает переданную во втором параметр инфомацию в вид js         скрипта     console.{действи}
    обратите внимане функция возвращает форатированную строку но не выводит ее, не забудте добавиь `echo`
    _полезно при работе на рабочем сайте для вывда debug информации_
    
    ```php
    $arr = [
        \'фрукт\'=>\'апельсин\',
        \'ягода\'=>\'арбуз\',
        ];
    echo $modx->util->console(\'log\',\'у меня есть\'); 
    //<script>console.log(\'(string): у меня есть\');</script>
    echo $modx->util->console(\'debug\',$arr); 
    //<script>console.debug({"фрукт":"апельсин","ягода":"арбуз"});</script>
    echo $modx->util->console(\'table\',$arr); 
    //<script>console.table({"фрукт":"апельсин","ягода":"арбуз"});</script>
    ```

- **dateFormat** - меняет формат даты
    _полезно если приходится проделывать это много раз_
    ```php
    $modx->util->dateFormat(\'d.m.Y\',\'29.01.2020\',\'Y-m-d\');//2020-01-29
    ```

- **rawText** - оставляет в строке только буквы и цифры
    _полезно когда нужно сравнить две строки с не большими отличиями_
    ```php
    $modx->util->rawText(\'Abs_#)/\\(_De\');//absde
    ```
- **likeString** - сравнивает две строки либо массив строк со строкой
    и выводит самую похожую строку и процент похожести
    ```php
    $arr = [
        \'Пивет\',
        \'Прлвeт\',
        \'Приет\',
        \'тивирТ\',
        \'привт\',
        \'досвидания\',
    ];
    var_dump($modx->util->likeString($arr,\'Привет\'));
    // array (size=3)
    //   \'one\' => string \'Приет\' (length=10)
    //   \'two\' => string \'Привет\' (length=12)
    //   \'score\' => float 90,909090909091
    
    $modx->util->data[\'likeString\']; //здесь будет массив с остальными словами и их процентом схожести
    ```

- **makeUrl** - делает тоже что и обычный makeUrl только умнее: ссылка всегда начинается с \'/\', если страница равна ссылке подставляется параметр alt по умолчанию \'#top\' 
    ```php
    //php
    $modx->util->makeUrl(1,\'#top\');
    ```
    ```fenom
    //fenom
    {util \'makeUrl\' 24}
    ```

- **or** - выдает первый не пустой аргумент
    _я использовал это вместе с fenom что бы не писать кучу условий_
    
    ```php
    //php
    $modx->util->or(0,false, null,\'\',\' \', \'привет\',\'кит\'); //привет
    ```
    ```fenom
    //fenom
    {util \'or\' 0 false null \'\' \' \'  \'привет\' \'кит\'}//привет
    ```


- **member** - функция для получения информации о группе пользователя

    *первый аргумент* - id пользователя если пустой то текущий авторезированный пользоваеть если авторизован

    *второй аргумент* - имя группы если установленно то, функция выдаст массив с ролью пользователя в этой группе или `false` если его в ней нет
    если yt установленно то, функция выдаст массив групп в которых состоит пользователь и его роль в них или `false`

    *третий аргумент* - можно заполнятьтолько вместе со вторым,
    функция выдаст `true` или `false`
 
    ```php
    //php
   $answer = $modx->util->member(1); 
   $answer = [
                {"groupId":"1","groupName":"Administrator","roleId":"2",    "roleName":"Super User"}
              ]
   $answer = $modx->util->member(1,\'Administrator\'); 
   $answer = {"roleId":"2","roleName":"Super User"}
   $answer = $modx->util->member(1,1,\'Super User\'); 
   $answer = true
    ```

- **plural** - функция для локализации перечисяемых объектов
    ```php
    echo $modx->util->plural(0.5,[\'арбуз\', \'арбуза\', \'арбузов\']); // арбузов;
	echo $modx->util->plural(51,[\'арбуз\', \'арбуза\', \'арбузов\']);  // арбуз;
	echo $modx->util->plural(-11,[\'арбуз\', \'арбуза\', \'арбузов\']); // арбузов;
	echo $modx->util->plural(2,[\'арбуз\', \'арбуза\', \'арбузов\']);   // арбуза;
    ```

- **convert** - функция для конфертации часто использемых едениц измерения
    *первый аргумент* - число 
    *второй аргумент* - тип единици измерения
    *третий аргумент* - еденица измерения по умолчанию SI(СИ)
    *четвертый аргумент* в какую еденицну нужно конвертировать по умолчанию best
    ```php
	echo $modx->util->convert(4000,\'byte\');                 // [3.9,"kb"]
	echo $modx->util->convert(10,\'mass\',  \'T\', \'kg\');       // [10000,"kg"]
	echo $modx->util->convert(1000000,\'length\',\'SI\', \'km\'); // [1000,"km"]
	echo $modx->util->convert(0.5,\'time\',  \'h\', \'min\');     // [30,"min"]
    ```
#### Классы
 - **Csv** 
    удобный класс для создания csv 
    особенности:
   - заполнять по строкам или по столбцам 
   - устанавливать шапку
   - изменять конкретнуб ячейку 

    ```php
    $csv = $modx->util->csv();
    $csv->setHead(\'c\',\'b\',\'a\');
    $csv->addRow([
          \'a\'=>\'1\',
          \'b\'=>\'2\',
          \'c\'=>\'3\',
        ]);
        $csv->addRow(5,6,7);
        $csv->setCell(\'b\',0,4444);
    echo $csv;
    /**
    c;b;a
    3;4444;1
    5;6;7
    */
    ```

     ```php
    $csv = $modx->util->csv();
    $csv->setHead(\'c\',\'b\',\'a\');
    $csv->addCol([
        \'a\'=>\'1\',
         \'b\'=>\'2\',
          \'c\'=>\'3\',
        ]);
        $csv->addCol(5,6,7);
    echo $csv->toCsv();
    /**
    a;1;7
    b;2;6
    c;3;5
    */
    ```',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4f615edb373819770cdc87e8c184909e',
      'native_key' => 'modutilities',
      'filename' => 'modNamespace/18123f3bb6d416800314d73b8fd7a8df.vehicle',
      'namespace' => 'modutilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '8e237fe3648b57b8137f68df2065746b',
      'native_key' => 15,
      'filename' => 'modPlugin/97edf2a1f977fcd971ebfc9ddc5ac5b9.vehicle',
      'namespace' => 'modutilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'df590c4984466076cadc1b63aae82897',
      'native_key' => 16,
      'filename' => 'modPlugin/dfde501e6a12ba3a504985d6c78d9b5b.vehicle',
      'namespace' => 'modutilities',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '72234cecd95627416987c5606bd7d452',
      'native_key' => 1,
      'filename' => 'modCategory/b32d094f3daaff08df5264673af80bfd.vehicle',
      'namespace' => 'modutilities',
    ),
  ),
);