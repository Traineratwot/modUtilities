# Changelog

## [2.0.2] - 2020-06-08

### Added

- csv->toHtml('classname')
