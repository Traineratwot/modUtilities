<?php
require_once (dirname(__DIR__) . '/utilrestcategory.class.php');
class Utilrestcategory_mysql extends Utilrestcategory {}